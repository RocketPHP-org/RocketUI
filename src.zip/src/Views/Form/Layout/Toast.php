<?php

namespace RocketPhp\RocketUI\Views\Form\Layout;

use RocketPhp\RocketUI\Views\Form\Layout\Abstract\AbstractLayout;

class Toast extends AbstractLayout
{

}
<?php

namespace RocketPhp\RocketUI\Views\Grid\Action;

class Button
{

}
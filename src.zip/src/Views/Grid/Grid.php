<?php

namespace RocketPhp\RocketUI\Views\Grid;

use RocketPhp\RocketUI\Views\Grid\Action\Button;
use RocketPhp\RocketUI\Views\Form\Layout\Layout;

class Grid
{
    private array $metadata;
    private array $columns;
    private array $actions;
    private array $gridOptions;
    private array $rowActions;

    /**
     * @throws \Exception
     */
    public function __construct(string $xmlPath)
    {
        $xml = new \DOMDocument();
        $xml->load($xmlPath);

        $this->metadata = $this->parseMetadata($xml);
        $this->columns = $this->parseColumns($xml);
        $this->actions = $this->parseActions($xml);
        $this->gridOptions = $this->parseGridOptions($xml);
        $this->rowActions = $this->parseRowActions($xml);
    }

    private function parseMetadata(\DOMDocument $xml): array
    {
        $metadataNode = $xml->getElementsByTagName("metadata")->item(0);
        if (!$metadataNode) {
            return [];
        }

        return [
            'title' => $metadataNode->getElementsByTagName("title")->item(0)?->nodeValue ?? '',
            'description' => $metadataNode->getElementsByTagName("description")->item(0)?->nodeValue ?? '',
            'version' => $metadataNode->getElementsByTagName("version")->item(0)?->nodeValue ?? '',
        ];
    }

    private function parseActions(\DOMDocument $xml): array
    {
        $actions = [];
        $actionsNode = $xml->getElementsByTagName("actions")->item(0);
        if (!$actionsNode) {
            return [];
        }

        foreach ($actionsNode->childNodes as $child) {
            if ($child->nodeType !== XML_ELEMENT_NODE) {
                continue;
            }

            switch ($child->nodeName) {
                case "button":
                    $actions[] = new Button($child);
                    break;
            }
        }

        return $actions;
    }

    private function parseGridOptions(\DOMDocument $xml): array
    {

    }
}